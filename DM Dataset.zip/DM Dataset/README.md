## About This Dataset

This dataset contains images of cats, dogs, and rabbits collected via web scraping from [Pexels.com](https://www.pexels.com/), a free stock photo site.

### License
All images are provided under the [Pexels License](https://www.pexels.com/license/), which allows free use for personal and commercial projects.

Please note that the original photographers own the copyright of the images, and proper attribution is appreciated but not required by Pexels.
